//ex03.js

//
//alert("안녕"); //BOM

//Ctrl + `(back quote) -> 디버그 콘솔
console.log("하이~"); //Core
