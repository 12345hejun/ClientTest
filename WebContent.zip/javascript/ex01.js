//ex01.js

alert("Hello");
